package com.example.bda2.Email;

public class Util {
        public static final String EMAIL="caringyouth22@gmail.com";
        public static  final String PASSWORD="Project#22";
}
